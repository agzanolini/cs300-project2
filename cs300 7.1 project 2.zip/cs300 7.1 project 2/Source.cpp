#include<algorithm>
#include<climits>
#include<iostream>
#include<string>
#include<cstring>
#include<vector>
#include <fstream>
#include <sstream>
#include <math.h>

using namespace std;

const unsigned int DEFAULT_SIZE = 19;

struct Course {
	string code;
	string title;
	vector<string> prereqs;
};

class HashTable {

private:

	struct Node {
		Course course;
		unsigned int key;
		Node* next;

		// default constructor
		Node() {
			key = UINT_MAX;
			next = nullptr;
		}

		// initialize with a bid
		Node(Course aCourse) : Node() {
			course = aCourse;
		}

		// initialize with a bid and a key
		Node(Course aCourse, unsigned int aKey) : Node(aCourse) {
			key = aKey;
		}
	};

	vector<Node> courses;

	unsigned int tableSize = DEFAULT_SIZE;

	unsigned int hash(int key);

public:
	HashTable();
	virtual ~HashTable();
	vector<string> Split(string line, string delimiter);
	void GetCourses();
	void Insert(Course course);
	void PrintCourseInfo(string courseCode);
	void PrintSampleSchedule();
};


HashTable::HashTable() {
	courses.resize(tableSize);
}

HashTable::~HashTable() {
	courses.erase(courses.begin(), courses.end());
}

bool invalidChar(char c) {
	return !(c >= 0 && c < 128); //input code had strange symbols--invalidChar and stripUnicode gets rid of them
}

void stripUnicode(string& str) {
	str.erase(remove_if(str.begin(), str.end(), invalidChar), str.end());
}

unsigned int HashTable::hash(int key) {
	return key % tableSize;
}

void HashTable::Insert(Course course) {
	int code = stoi(course.code.substr(4, 6)); //each course has a unique number on the end
	int key = hash(code);
	Node* node = &(courses.at(key));
	if (node == nullptr) {
		Node* pointer = new Node(course, key);
		courses.insert(courses.begin() + key, *pointer);
	}
	else {
		if (node->key == UINT_MAX) { //key exists but is empty
			node->key = key;
			node->course = course;
			node->next = nullptr;
		}
		else {
			while (node->next != nullptr) { //chaining until empty node is found
				node = node->next;
			}
			node->next = new Node(course, key);
		}
	}
}

vector<string> HashTable::Split(string line, string delimiter) {
	size_t pos_start = 0, pos_end, delim_len = delimiter.length();
	string token;
	vector<string> splitLine;

	while ((pos_end = line.find(delimiter, pos_start)) != string::npos) {//split string between commas, strip unicode symbols
		token = line.substr(pos_start, pos_end - pos_start);
		pos_start = pos_end + delim_len;
		stripUnicode(token);
		splitLine.push_back(token);
	}

	splitLine.push_back(line.substr(pos_start));
	return splitLine;
}

void HashTable::GetCourses() {
	ifstream inputFile;
	inputFile.open("ABCU_Advising_Program_Input.txt");

	if (!inputFile.is_open()) {
		cout << "Could not open file" << endl;
	}

	string line;

	while (getline(inputFile, line)) {
		vector<string> splitLine = Split(line, ",");
		if (splitLine.size() < 2) { //validate that all lines have a course code and title
			continue;
		}
		Course course = Course();
		course.code = splitLine[0];
		course.title = splitLine[1];
		if (splitLine.size() > 2) { //rest of the line is prerequisites--they will be stored in a vector
			vector<string> prereqs;
			int vectorSize = splitLine.size() - 3;
			prereqs.resize(vectorSize);
			for (int i = 2; i < splitLine.size(); ++i) {
				prereqs.push_back(splitLine.at(i));
			}
			course.prereqs = prereqs;
		}
		Insert(course);
		for (unsigned int i = 0; i < courses.size(); ++i) { //confirm all prerequisites are listed as courses
			vector<string> validPrereqs;
			for (unsigned int i = 0; i < course.prereqs.size(); ++i) { //compare all prereqs to courses
				for (unsigned int j = 0; j < courses.size(); ++j) {
					if (course.code == course.prereqs.at(i)) {
						validPrereqs.push_back(course.prereqs.at(i));
						break;
					}
				}
			}
			course.prereqs = validPrereqs;
		}
	}
}
void HashTable::PrintCourseInfo(string courseCode) { 
	if (courseCode.length() == 7 && isdigit(courseCode[4])) { //input validation
		int code = stoi(courseCode.substr(4, 6));
		int key = hash(code);
		Node* pointer = &(courses.at(key));
		if (pointer->course.code == courseCode) {
			cout << pointer->course.code << ", " << pointer->course.title;
			if (!pointer->course.prereqs.empty()) { //list prereqs if any
				cout << endl << "Prerequisites: ";
				for (unsigned int i = 0; i < pointer->course.prereqs.size(); ++i) {
					cout << pointer->course.prereqs[i] << " ";
				}
			}
			cout << endl;
			return;
		}
	}
	cout << "Course does not exist" << endl;
}

void HashTable::PrintSampleSchedule() {
	Node* currPointer = nullptr;
	vector<Course> sortedList; //hashtable is unsorted, send all courses to vector to bubble sort
	for (unsigned int i = 0; i < courses.size(); ++i) {
		currPointer = &(courses.at(i));
		if (currPointer->key != UINT_MAX) { //contains course
			sortedList.push_back(currPointer->course);
			currPointer = currPointer->next;
		}
	}
	
	Course temp;
	for (int i = 0; i < sortedList.size() - 1; ++i) { //bubble sort by course code
		for (int j = i + 1; j < sortedList.size(); ++j) {
			if (sortedList.at(j).code < sortedList.at(i).code) {
				temp = sortedList.at(i);
				sortedList.at(i) = sortedList.at(j);
				sortedList.at(j) = temp;
			}
		}
	}
	for (int i = 0; i < sortedList.size(); ++i) { //iterate through sorted list
		cout << sortedList.at(i).code << ", " << sortedList.at(i).title << endl;
	}
	
}

void main() {
	HashTable* table{}; //new empty hash table
	int input = 0;
	string inputCode = "";

	while (input != 4) {
		cout << "Main Menu" << endl;
		cout << "1. Load Data Structure" << endl;
		cout << "2. Print Course List" << endl;
		cout << "3. Print Course Information" << endl;
		cout << "4. Exit" << endl;
		
		cin >> input;

		if (input == 1) {
			table = new HashTable();
			table->GetCourses();
		}
		else if (input == 2) {
			cout << "Here is a sample schedule:" << endl;
			table->PrintSampleSchedule();
		}
		else if (input == 3) {
			cout << "What course would you like to know about?" << endl;
			cin >> inputCode;
			for (int i = 0; i < inputCode.length(); i++) { //validation to handle lowercase input
				inputCode[i] = toupper(inputCode[i]);
			}
			table->PrintCourseInfo(inputCode);
		}
		else if ((input != 4)) {
			cout << input << " is not a valid option." << endl << endl;
			continue;
		}
	}
	cout << "Thank you for using the course planner!" << endl;
}